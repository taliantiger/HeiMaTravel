create
    definer = root@localhost procedure processorders()
begin 
	-- declare local variables 
	declare done boolean default 0 ;
	declare o int ;
	declare t decimal(8, 2) ;
	
	-- declare the cursor 
	declare ordernumbers cursor 
	for 
	select order_num from orders ;
	
	-- Declare continue handler 
	declare continue handler for sqlstate '02000' set done = 1 ;
	
	-- Create a table to store the results 
	create table if not exists ordertotals  
		(order_num int, total decimal(8, 2) ) ;
		
	-- Open the cursor 
	open ordernumbers ;
	
	-- Loop through all rows 
	repeat 
		-- Get order number 
		fetch ordernumbers into o ;
		
		-- Get the total for this order 
		call ordertotal(o, 1, t) ;
		
		-- Insert order and total into ordertotals 
		insert into ordertotals(order_num, total ) 
		values(o, t) ;
		
		-- End of loop 
		until done end repeat ;
		
		-- Close the cursor 
		close ordernumbers ;
		
end;

