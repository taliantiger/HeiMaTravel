create definer = root@localhost trigger deleteorder
    before delete
    on orders
    for each row
begin 
	insert into archive_orders(order_num, order_date, cust_id) 
	value(OLD.order_num, OLD.order_date, OLD.cust_id) ;
end;

