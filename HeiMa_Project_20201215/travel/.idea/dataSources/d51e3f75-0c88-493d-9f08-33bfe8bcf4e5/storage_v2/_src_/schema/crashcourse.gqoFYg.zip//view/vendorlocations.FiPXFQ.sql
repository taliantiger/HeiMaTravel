create view vendorlocations as
select concat(rtrim(`crashcourse`.`vendors`.`vend_name`), '(', rtrim(`crashcourse`.`vendors`.`vend_country`),
              ')') AS `vend_title`
from `crashcourse`.`vendors`
order by `crashcourse`.`vendors`.`vend_name`;

