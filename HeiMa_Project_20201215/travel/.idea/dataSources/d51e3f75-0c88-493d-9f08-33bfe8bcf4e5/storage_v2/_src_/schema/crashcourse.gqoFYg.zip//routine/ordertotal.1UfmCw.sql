create
    definer = root@localhost procedure ordertotal(IN onumber int, OUT ototal decimal(8, 2))
begin 
	select sum(item_price * quantity) 
	from orderitems 
	where order_num = onumber
	into ototal;
end;

