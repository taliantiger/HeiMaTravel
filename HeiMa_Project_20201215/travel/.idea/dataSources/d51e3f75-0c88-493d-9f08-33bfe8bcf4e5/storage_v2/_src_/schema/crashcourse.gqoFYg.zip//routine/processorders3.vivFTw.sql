create
    definer = root@localhost procedure processorders3()
BEGIN 
	-- Declare the cursor 
	DECLARE ordernumbers CURSOR 
	FOR 
	SELECT order_num FROM orders ;
	
	-- Open the cursor 
	open ordernumbers ;
	
	-- close the cursor 
	close ordernumbers ;
	
END;

