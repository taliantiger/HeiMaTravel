create
    definer = root@localhost procedure ordertotal2(IN onumber int, IN taxable tinyint(1), OUT ototal decimal(8, 2))
    comment 'Obtain order total, optionally adding tax'
begin 
	-- declare variable for total 
	declare total decimal (8, 2) ;
	-- declare tax percentage 
	declare taxrate int default 6;
	
	-- get the order total 
	select sum(item_price * quantity ) 
	from orderitems 
	where order_num = onumber  
	into total; 
	
	-- Is this taxable ? 
	if taxable THen 
		-- Yes, so add taxrate to the total 
		select total + (total / 100 *  taxrate ) into total ;
	end if ;
	
	
	-- Abd finally, save to out variable 
	select total into ototal ;
end;

