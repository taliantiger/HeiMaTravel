create definer = root@localhost trigger updatevendor
    before update
    on vendors
    for each row
    set New.vend_state = upper(NEW.vend_state);

