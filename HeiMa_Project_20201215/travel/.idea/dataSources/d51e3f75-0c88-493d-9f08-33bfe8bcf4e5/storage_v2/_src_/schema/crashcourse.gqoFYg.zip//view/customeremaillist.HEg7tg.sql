create view customeremaillist as
select `crashcourse`.`customers`.`cust_id`    AS `cust_id`,
       `crashcourse`.`customers`.`cust_name`  AS `cust_name`,
       `crashcourse`.`customers`.`cust_email` AS `cust_email`
from `crashcourse`.`customers`
where (`crashcourse`.`customers`.`cust_email` is not null);

