create
    definer = root@localhost procedure processorders2()
begin 
	declare ordernumbers cursor 
	for 
	select order_num from orders ;
end;

