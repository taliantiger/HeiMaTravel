create view orderitemsexpanded3 as
select `crashcourse`.`orderitems`.`order_num`                                            AS `order_num`,
       `crashcourse`.`orderitems`.`prod_id`                                              AS `prod_id`,
       `crashcourse`.`orderitems`.`quantity`                                             AS `quantity`,
       `crashcourse`.`orderitems`.`item_price`                                           AS `item_price`,
       (`crashcourse`.`orderitems`.`quantity` * `crashcourse`.`orderitems`.`item_price`) AS `expanded_price`
from `crashcourse`.`orderitems`;

